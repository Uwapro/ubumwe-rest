


<html>
<head>
<link rel="stylesheet" type="text/css" href="css/sch.css">
<link rel="icon" style="image/jpg" href="../assignment/photoes/index.jpg">
<title>shakisha.com</title>
</head>

<body bgcolor="#3333CC">
<div class="banner">
SHAKISHA IBYANGOMBWA BYAWE
</div>
<img src="mtn.jpg" width="100%">
<div class="menubar">

<div class="dropdown">
<button class="dropbtn">Ahabanza</button>
  <div class="dropdown-content">
    <a href="index.php">Ahabanza</a>    </div>
</div> 

 <div class="dropdown">
<button class="dropbtn">Aboturibo</button>
  <div class="dropdown-content">
    <a href="student.php">Aboturibo</a>    </div>
</div> 

 <div class="dropdown">
<button class="dropbtn">Serivise zacu</button>
  <div class="dropdown-content">
    <a href="shakindang.php">Reba indangamuntu wataye</a>    
    <a href="register.php">Reba indangamuntu yawe</a>    </div>
</div>

 <div class="dropdown">
<button class="dropbtn">Ibiciro</button>
  <div class="dropdown-content">
    <a href="print1.php">Imyishyurire ya serivise</a>  
	 <a href="print1.php">Uburyo wa kwishyuramo</a> 
	 </div>
</div> 

<div class="dropdown">
<button class="dropbtn">Indimi</button>
  <div class="dropdown-content">
    <a href="login.php">Kinyarwanda</a>
	<a href="login.php">English</a>
	  </div>
</div>
</div>
<div class="word">


<u><b>UZUZA IBI BIKURIKIRA</b></u><br><br>
<i>
Izina:&nbsp;&nbsp;&nbsp;<input type="text" name="izina" required="required"><br><br>
Irindizina:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="irindi" required="required"><br><br>
Akarere wayifatiyemo:<input type="text" name="akar" required="required"><br><br>
Umurenge wayifatiyemo:<input type="text" name="umur" required="required"><br><br>
Ifoto:<input type="file" name="up"><br><br>
Intara:<input type="text" name="inta" required="required"><br><br>
Akarere:<input type="text" name="aka" required="required"><br><br>
Umurenge:<input type="text" name="umu" required="required"><br><br>
Akagari:<input type="text" name="umur" required="required"><br><br>
Station ya polisi:<input type="text" name="stat" required="required"><br><br>
Ahandi:<input type="text" name="aha" required="required"><br><br>
</i>
<input type="submit" name="send" value="Ohereza">
<input type="reset" value="Cancel">
</div>
<div class="footer">
<b>
Contact<br></b>
IHAHA SHOP <br>
P.O. Box 1017 Kigali-Rwanda</div>
</body>
</html>

